// Mobile Menu Toggle
document.getElementById('mobile-menu-button').addEventListener('click', function() {
  const menu = document.getElementById('mobile-menu');
  const icon = this.querySelector('i');
  
  menu.classList.toggle('hidden');
  icon.classList.toggle('fa-bars');
  icon.classList.toggle('fa-times');
});

// Counter Animation
const animateCounter = (element, target, duration = 2000) => {
  let start = 0;
  const increment = target / (duration / 16); // 60fps
  
  const updateCounter = () => {
    start += increment;
    if (start < target) {
      element.textContent = Math.floor(start);
      requestAnimationFrame(updateCounter);
    } else {
      element.textContent = target;
    }
  };
  
  updateCounter();
};

// Intersection Observer for counter animation
const observerOptions = {
  threshold: 0.5,
  rootMargin: '0px'
};

const observer = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      const counter = entry.target;
      const target = parseInt(counter.getAttribute('data-target'));
      animateCounter(counter, target);
      observer.unobserve(counter); // Stop observing after animation
    }
  });
}, observerOptions);

// Start observing all counters
document.querySelectorAll('.counter').forEach(counter => {
  observer.observe(counter);
});

// Scroll Reveal Animation
const scrollRevealElements = document.querySelectorAll('.scroll-reveal');

const revealOnScroll = () => {
  scrollRevealElements.forEach(element => {
    const elementTop = element.getBoundingClientRect().top;
    const elementVisible = 150;
    
    if (elementTop < window.innerHeight - elementVisible) {
      element.classList.add('visible');
    }
  });
};

window.addEventListener('scroll', revealOnScroll);
window.addEventListener('load', revealOnScroll);

// Smooth hover effects for cards
document.querySelectorAll('.hover-lift').forEach(card => {
  card.addEventListener('mousemove', (e) => {
    const rect = card.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    
    card.style.setProperty('--mouse-x', `${x}px`);
    card.style.setProperty('--mouse-y', `${y}px`);
  });
});

// Tab Switching Functionality
document.addEventListener('DOMContentLoaded', function() {
  const tabButtons = document.querySelectorAll('.tab-btn');
  const tabContents = document.querySelectorAll('.tab-content');

  tabButtons.forEach(button => {
    button.addEventListener('click', () => {
      // Remove active class from all buttons and contents
      tabButtons.forEach(btn => {
        btn.classList.remove('active', 'text-primary', 'border-primary');
        btn.classList.add('text-gray-500', 'border-transparent');
      });
      tabContents.forEach(content => content.classList.add('hidden'));

      // Add active class to clicked button
      button.classList.add('active', 'text-primary', 'border-primary');
      button.classList.remove('text-gray-500', 'border-transparent');

      // Show corresponding content
      const tabId = button.getAttribute('data-tab');
      document.getElementById(`${tabId}-tab`).classList.remove('hidden');
    });
  });
});

// Resource Tab Switching
document.addEventListener('DOMContentLoaded', function() {
  const resourceTabButtons = document.querySelectorAll('.tab-btn');
  const resourceItems = document.querySelectorAll('.resource-item');

  resourceTabButtons.forEach(button => {
    button.addEventListener('click', () => {
      // Remove active class from all buttons
      resourceTabButtons.forEach(btn => {
        btn.classList.remove('active', 'border-primary');
        btn.classList.add('border-transparent');
      });

      // Add active class to clicked button
      button.classList.add('active', 'border-primary');
      button.classList.remove('border-transparent');

      // Show/hide resources based on category
      const selectedCategory = button.getAttribute('data-tab');
      
      resourceItems.forEach(item => {
        if (selectedCategory === 'all' || item.getAttribute('data-category') === selectedCategory) {
          item.style.display = 'block';
        } else {
          item.style.display = 'none';
        }
      });
    });
  });
}); 